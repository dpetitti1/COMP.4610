Github URL where application resides:
https://dpetitti1.github.io/COMP.4610/HW3/

Github Repository:
dpetitti1.github.io/comp.4610/